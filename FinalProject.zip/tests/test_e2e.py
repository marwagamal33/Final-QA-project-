import pytest
from selenium import webdriver
from pages.register_page import RegisterPage
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage

def test_e2e_flow():
    driver = webdriver.Chrome()
    driver.get("https://cartlow.com/uae/en")

    # Register
    register = RegisterPage(driver)
    register.enter_name("Marwa Test")
    register.enter_email("marwa.test@example.com")
    register.enter_password("Test@1234")
    register.enter_confirm_password("Test@1234")
    register.click_register()

    # Login
    login = LoginPage(driver)
    login.enter_email("marwa.test@example.com")
    login.enter_password("Test@1234")
    login.click_login()

    # Add Laptop
    home = HomePage(driver)
    home.go_to_laptops()
    home.select_laptop("Dell Latitude 7490")
    cart = CartPage(driver)
    cart.add_to_cart(1)

    # Add Smartwatch
    home.go_to_smartwatches()
    home.select_watch("Apple Watch Series 6")
    cart.add_to_cart(2)

    # Cart Actions
    cart.open_cart()
    cart.remove_item("Dell Latitude 7490")
    cart.proceed_to_checkout()

    # Checkout
    checkout = CheckoutPage(driver)
    checkout.enter_address("Test Address")
    checkout.enter_payment_details("4111111111111111", "12/26", "123")
    checkout.place_order()

    driver.quit()
