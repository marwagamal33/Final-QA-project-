from selenium.webdriver.common.by import By

class CartPage:
    def __init__(self, driver):
        self.driver = driver

    def add_to_cart(self, quantity=1):
        for _ in range(quantity):
            self.driver.find_element(By.ID, "addToCartBtn").click()

    def open_cart(self):
        self.driver.find_element(By.ID, "cartBtn").click()

    def remove_item(self, name):
        self.driver.find_element(By.XPATH, f"//div[contains(text(), '{name}')]/../button[@class='remove']").click()

    def proceed_to_checkout(self):
        self.driver.find_element(By.ID, "checkoutBtn").click()
