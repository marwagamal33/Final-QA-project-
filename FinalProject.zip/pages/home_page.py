from selenium.webdriver.common.by import By

class HomePage:
    def __init__(self, driver):
        self.driver = driver

    def go_to_laptops(self):
        self.driver.find_element(By.LINK_TEXT, "Laptops").click()

    def go_to_smartwatches(self):
        self.driver.find_element(By.LINK_TEXT, "Smartwatches").click()

    def select_laptop(self, name):
        self.driver.find_element(By.PARTIAL_LINK_TEXT, name).click()

    def select_watch(self, name):
        self.driver.find_element(By.PARTIAL_LINK_TEXT, name).click()
