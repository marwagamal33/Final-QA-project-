from selenium.webdriver.common.by import By

class CheckoutPage:
    def __init__(self, driver):
        self.driver = driver

    def enter_address(self, address):
        self.driver.find_element(By.ID, "address").send_keys(address)

    def enter_payment_details(self, card_number, expiry, cvv):
        self.driver.find_element(By.ID, "cardNumber").send_keys(card_number)
        self.driver.find_element(By.ID, "expiryDate").send_keys(expiry)
        self.driver.find_element(By.ID, "cvv").send_keys(cvv)

    def place_order(self):
        self.driver.find_element(By.ID, "placeOrderBtn").click()
