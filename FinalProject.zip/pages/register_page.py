from selenium.webdriver.common.by import By

class RegisterPage:
    def __init__(self, driver):
        self.driver = driver
        self.name_input = (By.ID, "name")
        self.email_input = (By.ID, "email")
        self.password_input = (By.ID, "password")
        self.confirm_password_input = (By.ID, "confirmPassword")
        self.register_button = (By.ID, "registerBtn")

    def enter_name(self, name):
        self.driver.find_element(*self.name_input).send_keys(name)

    def enter_email(self, email):
        self.driver.find_element(*self.email_input).send_keys(email)

    def enter_password(self, password):
        self.driver.find_element(*self.password_input).send_keys(password)

    def enter_confirm_password(self, password):
        self.driver.find_element(*self.confirm_password_input).send_keys(password)

    def click_register(self):
        self.driver.find_element(*self.register_button).click()
